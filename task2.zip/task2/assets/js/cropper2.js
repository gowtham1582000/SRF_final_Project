let result = document.querySelector('.cropimageresult'),
save = document.querySelector('.preview'),
croppedImage = document.querySelector('.croppedImage'),
croppedImageName = document.querySelector('.cropFileName'),
upload = document.querySelector('#file-input'),
cropper = '';

// on change show image with crop options
upload.addEventListener('change', e => {
    $('#imageCropper').modal('show');
    setTimeout(() => {
        if (e.target.files.length) {
            console.log(e.target.files);
            document.querySelector('.cropFileName').innerHTML = e.target.files[0].name;
            // start file reader
            const reader = new FileReader();
            reader.onload = e => {
                if (e.target.result) {
                // create new image
                let img = document.createElement('img');
                img.id = 'image';
                img.src = e.target.result;
                // clean result before
                result.innerHTML = '';
                // append new image
                result.appendChild(img);
                // show save btn and options
                save.classList.remove('hide');
                // init cropper
                cropper = new Cropper(img, {
                        dragMode: 'move',
                        aspectRatio: 1 / 1,
                        autoCropArea: 0.65,
                        restore: false,
                        guides: false,
                        center: true,
                        highlight: false,
                        //cropBoxMovable: false,
                        cropBoxResizable: false,
                        toggleDragModeOnDblclick: false,
                         
                    });
                }
            };
            reader.readAsDataURL(e.target.files[0]);
        }
    }, 300);
});

// save on click
save.addEventListener('click', e => {

    console.log(cropper.getCanvasData());
    e.preventDefault();
    let imgSrc = cropper.getCroppedCanvas({
        //width: img_w.value, // input value
    
        fillColor: '#000',
        imageSmoothingEnabled: true,
        imageSmoothingQuality: 'high'
    }).toDataURL();

    croppedImage.setAttribute('src', imgSrc);
    $('#imageCropper').modal('hide');


   
    var canvas = $("#canvas")[0];
    var context = canvas.getContext('2d');
    var img = new Image();
    img.onload = function () {
        canvas.height = img.height;
         canvas.width =img.width;
        context.drawImage(img, 0, 0);
         
    };
    img.src =  imgSrc


});

  // Methods
  actions.querySelector('.docs-buttons').onclick = function(event) {
    var e = event || window.event;
    var target = e.target || e.srcElement;
    var cropped;
    var result;
    var input;
    var data;

    if (!cropper) {
      return;
    }

    while (target !== this) {
      if (target.getAttribute('data-method')) {
        break;
      }

      target = target.parentNode;
    }

    if (target === this || target.disabled || target.className.indexOf('disabled') > -1) {
      return;
    }

    data = {
      method: target.getAttribute('data-method'),
      target: target.getAttribute('data-target'),
      option: target.getAttribute('data-option') || undefined,
      secondOption: target.getAttribute('data-second-option') || undefined
    };

    cropped = cropper.cropped;

    if (data.method) {
      if (typeof data.target !== 'undefined') {
        input = document.querySelector(data.target);

        if (!target.hasAttribute('data-option') && data.target && input) {
          try {
            data.option = JSON.parse(input.value);
          } catch (e) {
            console.log(e.message);
          }
        }
      }

      switch (data.method) {
        case 'rotate':
          if (cropped) {
            cropper.clear();
          }

          break;

        case 'getCroppedCanvas':
          try {
            data.option = JSON.parse(data.option);
          } catch (e) {
            console.log(e.message);
          }

          if (uploadedImageType === 'image/jpeg') {
            if (!data.option) {
              data.option = {};
            }

            data.option.fillColor = '#fff';
          }

          break;
      }

      result = cropper[data.method](data.option, data.secondOption);

      switch (data.method) {
        case 'rotate':
          if (cropped) {
            cropper.crop();
          }

          break;

        case 'scaleX':
        case 'scaleY':
          target.setAttribute('data-option', -data.option);
          break;

        case 'getCroppedCanvas':
          if (result) {
            // Bootstrap's Modal
            $('#getCroppedCanvasModal').modal().find('.modal-body').html(result);

            if (!download.disabled) {
              download.href = result.toDataURL(uploadedImageType);
            }
          }

          break;

        case 'destroy':
          cropper = null;

          if (uploadedImageURL) {
            URL.revokeObjectURL(uploadedImageURL);
            uploadedImageURL = '';
            image.src = originalImageURL;
          }

          break;
      }

      if (typeof result === 'object' && result !== cropper && input) {
        try {
          input.value = JSON.stringify(result);
        } catch (e) {
          console.log(e.message);
        }
      }
    }
  };