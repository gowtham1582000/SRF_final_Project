//Student Information
var studentInfo = {
    studentName: "Demo User Name",
    studentClass : "7th",
    studentSection : "B Sec",
    studentTeacher : "Demo Teacher Name",
    studentHouse: "Demo House",
    studenAdmissionNo : "SRF11110777",
    studentBusNo : "11",
    studentStop: "Demo student Stop",
    studentResAddress: "No 123, Demo Street, Chennai - 600103",
    studentPhoneNo : "9876543210",
    studentMothersName: "Demo Mother Name",
    studentMotherOccupation : "House Wife",
    studentotherDesignation : "House Wife",
    studentMotherOrgName : "-",
    studentMotherTeleNo : "9876543210",
    studentMotherEmail : "-",
    studentFathersName : "Demo Father Name",
    studentFatherOccupation : "Driver",
    studentFatherDesignation : "Driver",
    studentFatherOrgName : "India Private Limited",
    studentFatherOrgName2: "India Private Limited",
    studentFatherTeleNo : "9876543210",
    studentFatherEmail : "demoName@gmail.com",
    studentEmergencyTeleNo : "9876543210",
    studentBloodGroup : "O Positive",
    studentAllergies : "No",
    studentAadhaarNo : "147825893699",
    studentMedicalDetails : "Fine",
    studentMedicalDetails2 : "Fine",
    studentSiblingsName : "Demo Brother Name",
    studentSiblingsCampus : "Don Bosco",
    studentSiblingsClass : "10th & B Sec",
    studentSiblingsTeacher : "Demo Teacher Name",
    studentParentSignatureImage: "dummy-signature.png",
    studentParentSignatureName: "Demo Father Name",
    studentParentSignatureDate: "13/12/2021"
};

$(document).ready(function () {
    //Get Label Width
    $(".pageinfo2").each(function (){
        var getLabelWidth = $(this).children("label").innerWidth();
        $(this).children("label").attr("value", getLabelWidth).css("min-width", getLabelWidth);
    });

    //Set Year
    var getYear1 = new Date();
    var getYear2 = getYear1.getFullYear();
    $(".year").text(`${getYear2}-${getYear2 + 1}`);

    //Turn.js Setting
    $("#flipbook").turn({
        width: 1000,
        height: 600,
        page: 1,
        autoCenter: true,
        duration: 2000
    });

    //Get Flipbook Height
    $(".flipbooksection, .pagecontent").css("height", $("#flipbook").height());

    //Previous Page Button
    $("#prevBtn").click(function() {
        $("#flipbook").turn("previous");
    });

    //Next Page Button
    $("#nextBtn").click(function() {
        $("#flipbook").turn("next");
    });
    

    //Assign Value
    $(".studentName").text(studentInfo.studentName);
    $(".studentClass").text(studentInfo.studentClass);
    $(".studentSection").text(studentInfo.studentSection);
    $(".studentClassSection").text(`${studentInfo.studentClass}, ${studentInfo.studentSection}`);
    $(".studentTeacher").text(studentInfo.studentTeacher);
    $(".studentHouse").text(studentInfo.studentHouse);
    $(".studenyAdmissionNo").text(studentInfo.studenAdmissionNo);
    $(".studentBusNo").text(studentInfo.studentBusNo);
    $(".studentStop").text(studentInfo.studentStop);
    $(".studentResAddress").text(studentInfo.studentResAddress);
    $(".studentPhoneNo").text(studentInfo.studentPhoneNo);
    $(".studentMothersName").text(studentInfo.studentMothersName);
    $(".studentMotherOccupation").text(studentInfo.studentMotherOccupation);
    $(".studentotherDesignation").text(studentInfo.studentotherDesignation);
    $(".studentMotherOrgName").text(studentInfo.studentMotherOrgName);
    $(".studentMotherTeleNo").text(studentInfo.studentMotherTeleNo);
    $(".studentMotherEmail").text(studentInfo.studentMotherEmail);
    $(".studentFathersName").text(studentInfo.studentFathersName);
    $(".studentFatherOccupation").text(studentInfo.studentFatherOccupation);
    $(".studentFatherDesignation").text(studentInfo.studentFatherDesignation);
    $(".studentFatherOrgName").text(studentInfo.studentFatherOrgName);
    $(".studentFatherOrgName2").text(studentInfo.studentFatherOrgName2);
    $(".studentFatherTeleNo").text(studentInfo.studentFatherTeleNo);
    $(".studentFatherEmail").text(studentInfo.studentFatherEmail);
    $(".studentEmergencyTeleNo").text(studentInfo.studentEmergencyTeleNo);
    $(".studentBloodGroup").text(studentInfo.studentBloodGroup);
    $(".studentAllergies").text(studentInfo.studentAllergies);
    $(".studentAadhaarNo").text(studentInfo.studentAadhaarNo);
    $(".studentMedicalDetails").text(studentInfo.studentMedicalDetails);
    $(".studentMedicalDetails2").text(studentInfo.studentMedicalDetails2);
    $(".studentSiblingsName").text(studentInfo.studentSiblingsName);
    $(".studentSiblingsCampus").text(studentInfo.studentSiblingsCampus);
    $(".studentSiblingsClass").text(studentInfo.studentSiblingsClass);
    $(".studentSiblingsTeacher").text(studentInfo.studentSiblingsTeacher);
    $(".studentParentSignatureImage").attr("src", "assets/images/" + studentInfo.studentParentSignatureImage);
    $(".studentParentSignatureName").text(studentInfo.studentParentSignatureName);
    $(".studentParentSignatureDate").text(studentInfo.studentParentSignatureDate);
});